prompt --application/shared_components/user_interface/lovs/mp2_customers_cust_name
begin
--   Manifest
--     MP2_CUSTOMERS.CUST_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>47072425936041572330
,p_default_application_id=>126948
,p_default_id_offset=>0
,p_default_owner=>'WKSP_YEDYGEBIS'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(2501017209901992658)
,p_lov_name=>'MP2_CUSTOMERS.CUST_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'MP2_CUSTOMERS'
,p_return_column_name=>'CUST_ID'
,p_display_column_name=>'CUST_NAME'
,p_default_sort_column_name=>'CUST_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
